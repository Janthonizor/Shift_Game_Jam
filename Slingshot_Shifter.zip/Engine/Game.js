import { Camera } from "../Rendering/Camera.js";
import {Physics } from "./Physics.js"
import { OrbSpatialGrid } from "./OrbSpatialGrid.js";


export class Game {

    constructor(renderer) {

        this.renderer = renderer;
        this.orb_texture = null;
        this.checkpoint_texture = null;

        this.player = {
            x: 32,
            y: 32,
            width: 64,
            height: 64,

            mass: 100,
            moveForce: 8000,
            drag: 10,
            bounciness: 0.9,

            vx: 0,
            vy: 0,
            ax: 0,
            ay: 0,

            prevVx: 0,
            prevVy: 0,
            texture: null,
            orbRange: 200,
            direction: 0,
        };

        this.camera = new Camera(renderer.canvas.width, renderer.canvas.height);
        this.camera.set_position(this.player.x, this.player.y);

        this.physics = new Physics()

        this.level = {
            background: {
                x: 500,
                y: 500, 
                width: 1000,
                height: 1000
            },
            orbs: [
                {
                    x: 500,
                    y: 500,
                    width: 64,
                    height: 64,
                    texture: null
                },
                {
                    x: 100,
                    y: 300,
                    width: 64,
                    height: 64,
                    texture: null
                },
                {
                    x: 800,
                    y: 100,
                    width: 64,
                    height: 64,
                    texture: null
                }
            ],
            checkpoints: [],
        };

        this.orbGrid = new OrbSpatialGrid(256);
        this.orbGrid.build(this.level.orbs);

        this.nearbyOrbs = [];


        this.input = {
            w: false,
            a: false,
            s: false,
            d: false,
            shift: false,
            g: false,
        }

        let shiftPressed = false;
        let gPressed = false;

        window.addEventListener("keydown", (event) => {
            const key = event.key.toLowerCase();

            if (key === "shift") {

                if (!shiftPressed) {

                    // Disengage if already engaged
                    if (this.input.shift) {
                        this.input.shift = false;
                    }

                    // Only engage if nearby orbs exist
                    else if (this.nearbyOrbs.length > 0) {
                        this.input.shift = true;
                    }

                    shiftPressed = true;
                }

                event.preventDefault();
                return;
            }
            if (key == "g"){
                if (!gPressed) {
                    this.input.g = !this.input.g;
                    gPressed = true
                }
                event.preventDefault();
                return;
            }

            if (key in this.input) {
                this.input[key] = true;
                event.preventDefault();
            }
        });

        window.addEventListener("keyup", (event) => {
            const key = event.key.toLowerCase();

            if (key === "shift") {
                shiftPressed = false;
                event.preventDefault();
                return;
            }
            if (key === "g") {
                gPressed = false;
                event.preventDefault();
                return;
            }

            if (key in this.input) {
                this.input[key] = false;
                event.preventDefault();
            }
        });
        this.renderer.canvas.addEventListener("wheel", (event) => {

            event.preventDefault();

            this.camera.adjust_zoom(event.deltaY);

        }, { passive: false });

        this.running = false;
    }
    

    async start() {

        this.player.texture = await this.renderer.load_render_texture(
            "./Assets/Player.png"
        );
        this.level.background.texture = await this.renderer.load_render_texture(
            "./Assets/grid_background.png"
        )
        this.orb_texture = await this.renderer.load_render_texture(
            "./Assets/orb.png"
        )
        for (const orb of this.level.orbs) {
            orb.texture = this.orb_texture;
        }
        console.log("Textures loaded:", this.player.texture);


        this.running = true;

        requestAnimationFrame(this.loop);
    }

    loop = (timestamp) => {

        if (!this.running) return;

        if (!this.lastTime) {
            this.lastTime = timestamp;
        }

        const dt = Math.min(
            (timestamp - this.lastTime) / 1000,
            0.05
        );

        this.lastTime = timestamp;

        this.update(dt);
        this.renderer.ditheringEnabled = !this.input.g;

        this.renderer.render(
            this.level,
            this.player,
            this.camera
        );

        requestAnimationFrame(this.loop);
    }


    updateValidOrbs() {

        const player = this.player;

        this.nearbyOrbs = this.orbGrid.getNearby(
            player.x,
            player.y,
            player.orbRange
        );


    }


    updateCamera(dt) {

        const player = this.player;
        const lookBehind = 0.15;
        this.camera.reset_size(this.renderer.canvas.width, this.renderer.canvas.height);

        this.camera.set_target_position(
            player.x - player.vx * lookBehind,
            player.y - player.vy * lookBehind
        );

        this.camera.move_toward_target_position(dt);
    }

    //update loop
    update(dt) {

        // Find orbs within interaction range
        this.updateValidOrbs();
        console.log("Nearby orbs:", this.nearbyOrbs);

        // Update physics
        this.physics.update(
            this.player,
            this.input,
            this.level.background,
            this.nearbyOrbs,
            dt
        );

        this.updateCamera(dt);

    }

}