import { loadTexture } from "./Texture.js";
import { ditheringSettings } from "./Dithering.js";


async function loadShader(path) {

    const response = await fetch(path);

    if (!response.ok) {
        throw new Error(`Failed to load shader: ${path}`);
    }

    return response.text();
}


const [vertexShaderSource, fragmentShaderSource] =
    await Promise.all([
        loadShader(new URL("./Shaders/vertex.vert", import.meta.url)),
        loadShader(new URL("./Shaders/fragment.frag", import.meta.url))
    ]);



export class Renderer {


    constructor(canvas) {

        this.canvas = canvas;
        this.gl = canvas.getContext("webgl2");

        if (!this.gl) {
            throw new Error("WebGL 2 initialization failed.");
        }

        const gl = this.gl;

        gl.viewport(0, 0, canvas.width, canvas.height);

        gl.enable(gl.BLEND);
        gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);


        this.program = this.createProgram(
            gl,
            vertexShaderSource,
            fragmentShaderSource
        );


        this.resolutionLocation = gl.getUniformLocation(
            this.program,
            "u_resolution"
        );

        this.textureLocation = gl.getUniformLocation(
            this.program,
            "u_texture"
        );


        this.positionLocation = gl.getAttribLocation(
            this.program,
            "a_position"
        );

        this.texCoordLocation = gl.getAttribLocation(
            this.program,
            "a_texCoord"
        );

        this.ditheringEnabled = true;

        this.worldDithering = true;

        this.vertexBuffer = gl.createBuffer();

        this.ditheringUniforms = {
            worldDithering: gl.getUniformLocation(
                this.program,
                "u_worldDithering"
            ),
            backgroundPosition: gl.getUniformLocation(
                this.program,
                "u_backgroundPosition"
            ),

            backgroundSize: gl.getUniformLocation(
                this.program,
                "u_backgroundSize"
            ),
            enabled: gl.getUniformLocation(
                this.program, 
                "u_ditheringEnabled"
            ),
            matrixSize: gl.getUniformLocation(
                this.program,
                "u_matrixSize"
            ),
            bayerMatrix: gl.getUniformLocation(
                this.program, 
                "u_bayerMatrix[0]"
            ),
            palette: gl.getUniformLocation(
                this.program, 
                "u_palette[0]"
            ),
            cutoffs: gl.getUniformLocation(
                this.program, 
                "u_cutoffs[0]"
            ),
            cutoffStrength: gl.getUniformLocation(
                this.program, 
                "u_cutoffStrength"
            ),

            cameraPosition: gl.getUniformLocation(this.program, "u_cameraPosition"),
            zoom: gl.getUniformLocation(this.program, "u_zoom")
        };

        this.uploadDitheringSettings(ditheringSettings);

        this.darkTexture = this.createDarkTexture();
        this.createSceneFramebuffer();
    }


    createShader(gl, type, source) {

        const shader = gl.createShader(type);

        gl.shaderSource(shader, source);
        gl.compileShader(shader);

        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {

            const error = gl.getShaderInfoLog(shader);

            gl.deleteShader(shader);

            throw new Error(error);
        }

        return shader;
    }


    createProgram(gl, vertexSource, fragmentSource) {

        const vertexShader = this.createShader(
            gl,
            gl.VERTEX_SHADER,
            vertexSource
        );

        const fragmentShader = this.createShader(
            gl,
            gl.FRAGMENT_SHADER,
            fragmentSource
        );

        const program = gl.createProgram();

        gl.attachShader(program, vertexShader);
        gl.attachShader(program, fragmentShader);

        gl.linkProgram(program);

        if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {

            const error = gl.getProgramInfoLog(program);

            gl.deleteProgram(program);
            gl.deleteShader(vertexShader);
            gl.deleteShader(fragmentShader);

            throw new Error(error);
        }

        gl.deleteShader(vertexShader);
        gl.deleteShader(fragmentShader);

        return program;
    }


    createSceneFramebuffer() {

        const gl = this.gl;

        this.sceneFramebuffer = gl.createFramebuffer();
        this.sceneTexture = gl.createTexture();

        gl.bindTexture(gl.TEXTURE_2D, this.sceneTexture);

        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);

        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

        gl.bindFramebuffer(gl.FRAMEBUFFER, this.sceneFramebuffer);

        gl.framebufferTexture2D(
            gl.FRAMEBUFFER,
            gl.COLOR_ATTACHMENT0,
            gl.TEXTURE_2D,
            this.sceneTexture,
            0
        );

        this.resizeSceneFramebuffer();

        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    }


    resizeSceneFramebuffer() {

        const gl = this.gl;
        const rect = this.canvas.getBoundingClientRect();

        const width = Math.round(rect.width);
        const height = Math.round(rect.height);

        if (width <= 0 || height <= 0) return;

        // Resize canvas drawing buffer
        this.canvas.width = width;
        this.canvas.height = height;

        // Resize scene texture
        gl.bindTexture(gl.TEXTURE_2D, this.sceneTexture);

        gl.texImage2D(
            gl.TEXTURE_2D,
            0,
            gl.RGBA8,
            width,
            height,
            0,
            gl.RGBA,
            gl.UNSIGNED_BYTE,
            null
        );

        gl.bindFramebuffer(gl.FRAMEBUFFER, this.sceneFramebuffer);

        if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) {
            throw new Error("Scene framebuffer is incomplete.");
        }

        gl.bindFramebuffer(gl.FRAMEBUFFER, null);

        this.sceneWidth = width;
        this.sceneHeight = height;

        gl.viewport(0, 0, width, height);
    }

    uploadDitheringSettings(settings) {

        const gl = this.gl;
        const uniforms = this.ditheringUniforms;

        gl.useProgram(this.program);

        gl.uniform1i(
            uniforms.matrixSize,
            settings.matrixSize
        );

        gl.uniform1fv(
            uniforms.bayerMatrix,
            new Float32Array(settings.bayerMatrix)
        );

        gl.uniform3fv(
            uniforms.palette,
            new Float32Array(
                settings.palette.flat().map(value => value / 255)
            )
        );

        gl.uniform1fv(
            uniforms.cutoffs,
            new Float32Array(settings.cutoffs)
        );

        gl.uniform1f(
            uniforms.cutoffStrength,
            settings.cutoffStrength
        );
    }


    uploadCameraSettings(camera) {

        const gl = this.gl;
        const uniforms = this.ditheringUniforms;

        gl.uniform2f(
            uniforms.cameraPosition,
            camera.x,
            camera.y
        );

        gl.uniform1f(
            uniforms.zoom,
            camera.zoom
        );
    }


    uploadBackgroundSettings(background) {

        const gl = this.gl;
        const uniforms = this.ditheringUniforms;

        gl.uniform2f(
            uniforms.backgroundPosition,
            background.x,
            background.y
        );

        gl.uniform2f(
            uniforms.backgroundSize,
            background.width,
            background.height
        );

    }


    uploadWorldDithering(){
        this.gl.uniform1i(
            this.ditheringUniforms.worldDithering,
            this.worldDithering? 1: 0
        );
    }


    load_render_texture(path) {
        return loadTexture(this.gl, path);
    }


    createDarkTexture() {

        const gl = this.gl;

        const texture = gl.createTexture();

        gl.bindTexture(gl.TEXTURE_2D, texture);

        gl.texImage2D(
            gl.TEXTURE_2D,
            0,
            gl.RGBA,
            1,
            1,
            0,
            gl.RGBA,
            gl.UNSIGNED_BYTE,
            new Uint8Array([10, 10, 10, 255])
        );

        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);

        return texture;
    }


    renderSprite(sprite, camera = null) {

        const gl = this.gl;

        if (!sprite.texture) return;

        const position = camera
            ? camera.worldToScreen(sprite.x, sprite.y)
            : { x: sprite.x, y: sprite.y };

        const zoom = camera ? camera.zoom : 1;

        const width = sprite.width * zoom;
        const height = sprite.height * zoom;

        const left = position.x - width / 2;
        const top = position.y - height / 2;

        const right = left + width;
        const bottom = top + height;

        const vertices = new Float32Array([

            left,  top,       0, 1,
            right, top,       1, 1,
            left,  bottom,    0, 0,

            left,  bottom,    0, 0,
            right, top,       1, 1,
            right, bottom,    1, 0
        ]);

        gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexBuffer);

        gl.bufferData(
            gl.ARRAY_BUFFER,
            vertices,
            gl.DYNAMIC_DRAW
        );

        gl.enableVertexAttribArray(this.positionLocation);

        gl.vertexAttribPointer(
            this.positionLocation,
            2,
            gl.FLOAT,
            false,
            16,
            0
        );

        gl.enableVertexAttribArray(this.texCoordLocation);

        gl.vertexAttribPointer(
            this.texCoordLocation,
            2,
            gl.FLOAT,
            false,
            16,
            8
        );

        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, sprite.texture);

        gl.uniform1i(this.textureLocation, 0);

        gl.drawArrays(gl.TRIANGLES, 0, 6);
    }



    render(level, player, camera) {

        const gl = this.gl;

        const rect = this.canvas.getBoundingClientRect();

        const width = Math.round(rect.width);
        const height = Math.round(rect.height);

        // Resize framebuffer if client dimensions changed
        if (
            this.sceneWidth !== width ||
            this.sceneHeight !== height
        ) {
            this.resizeSceneFramebuffer();
        }

        


        // ============================================================
        // PASS 1: RENDER SCENE
        // ============================================================

        gl.bindFramebuffer(gl.FRAMEBUFFER, this.sceneFramebuffer);

        gl.viewport(
            0,
            0,
            this.canvas.width,
            this.canvas.height
        );

        gl.enable(gl.BLEND);
        gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

        gl.clearColor(0, 0, 0, 1);
        gl.clear(gl.COLOR_BUFFER_BIT);

        gl.useProgram(this.program);
        gl.uniform1i(this.ditheringUniforms.enabled, 0);

        gl.uniform2f(
            this.resolutionLocation,
            this.canvas.width,
            this.canvas.height
        );

        this.uploadCameraSettings(camera);

        this.uploadBackgroundSettings(level.background);
        
        this.uploadWorldDithering();


        // Background
        this.renderSprite({
            x: this.canvas.width / 2,
            y: this.canvas.height / 2,
            width: this.canvas.width,
            height: this.canvas.height,
            texture: this.darkTexture
        });


        // Objects
        this.renderSprite(level.background, camera);

        for (const sprite of level.orbs) {
            console.log(sprite);
            console.log("Rendering sprite:", sprite);
            this.renderSprite(sprite, camera);
        }
        console.log("finished rendering orbs");

        // Player
        this.renderSprite(player, camera);


        // ============================================================
        // PASS 2: DITHER FRAMEBUFFER
        // ============================================================

        gl.bindFramebuffer(gl.FRAMEBUFFER, null);

        gl.viewport(
            0,
            0,
            this.canvas.width,
            this.canvas.height
        );

        gl.disable(gl.BLEND);

        gl.clearColor(0, 0, 0, 1);
        gl.clear(gl.COLOR_BUFFER_BIT);

        gl.useProgram(this.program);

        gl.uniform2f(
            this.resolutionLocation,
            this.canvas.width,
            this.canvas.height
        );

        gl.uniform1i(
            this.ditheringUniforms.enabled,
            this.ditheringEnabled ? 1 : 0
        );


        // Draw framebuffer texture across entire screen
        this.renderSprite({
            x: this.canvas.width / 2,
            y: this.canvas.height / 2,
            width: this.canvas.width,
            height: this.canvas.height,
            texture: this.sceneTexture
        });
    }


}
